package com.geospatial.geospatial.Repository;

public interface DeliveryOrderDao {



}
